A SimHub ShakeIt Device emulator for XBOX Series S/X Controller

Prerequisites:
SinHub (Licensed if you want 60FPS) https://www.simhubdash.com/
com0com http://sourceforge.net/projects/com0com/

Usage:
run com0com setup, verify pair using COM numbers
run SimHub, connect to Arduino ShakeIt device Import profile or Enable manually.
